#fonctions utilitaires pour calculer les signatures d’un fichier, 
# comparer ses signatures à celles d’un autre fichier, etc

#!/usr/bin/env python3
