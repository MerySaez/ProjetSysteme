#!/usr/bin/env python3  

import receiver, sys

#simple connexion avec le serveur
def serveur():
    receiver.receiver()



